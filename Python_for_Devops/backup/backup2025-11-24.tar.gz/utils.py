
import os

print(os.system("df -h"))
print(os.system("uptime"))
print(os.system("free -h"))

import os
command = 'ls'
def hello_fun(command):
    print(os.system(command))

hello_fun('ls') 


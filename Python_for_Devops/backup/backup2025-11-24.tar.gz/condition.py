
x = int(input("Emter the number:"))

if x > 0:
    print("x is grtatetr")
else:
    print("x is smaller")

x = input("enter the name:")
print(x)

print("Hello Dosto")
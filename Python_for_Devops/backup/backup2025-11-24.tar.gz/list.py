
list_of_cloud = ["AWS","Azure","gcp"]
print(list_of_cloud)

# insert the element in list

list_of_cloud.insert(3,"alibaba")
print(list_of_cloud)
# append the element

list_of_cloud.append("IBM")
print(list_of_cloud)

# remove the element

list_of_cloud.remove("AWS")
print(list_of_cloud)

print(len(list_of_cloud))

# itterate

for i in list_of_cloud:
    print(i)
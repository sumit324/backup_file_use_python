
import boto3
 
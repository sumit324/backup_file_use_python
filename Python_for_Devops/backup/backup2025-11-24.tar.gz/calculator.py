
num_1 = int(input("enter the number1:"))
num_2 = int(input("enter the number2:"))



sum = num_1 + num_2
print("enter the sum:",sum)

diff = num_1 - num_2
print("diff:",diff)

product = num_1 * num_2
print("product:",product)

division = num_1 / num_2
print("division:",division)